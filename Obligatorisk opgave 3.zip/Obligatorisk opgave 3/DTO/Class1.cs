﻿using System;

namespace DTO
{
    public class Class1
    {
    }
}
